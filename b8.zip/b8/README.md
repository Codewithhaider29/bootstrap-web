# ScrollTrigger: SVG Text Mask

A Pen created on CodePen.io. Original URL: [https://codepen.io/creativeocean/pen/qBbBLyB](https://codepen.io/creativeocean/pen/qBbBLyB).

This is a recreation of Unfold's (https://dribbble.com/unfold) parallax scene: https://cdn.dribbble.com/users/14268/screenshots/3275340/northface.gif

Mountain imagery from: https://www.worldwildlife.org/habitats/mountains